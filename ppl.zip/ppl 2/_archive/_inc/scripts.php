<!-- site JS -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="_scripts/jquery.easing-1.3.js"></script>
<script type="text/javascript" src="_scripts/jquery.jpanelmenu.min.js"></script>
<script type="text/javascript" src="_scripts/jquery.royalslider.min.js"></script>
<script type="text/javascript" src="_scripts/script.js"></script>

