<nav class="nav">

    <div class="row">
        <a href="index.php" class="logo">Christian Family Medicine</a>

        <ul class="menu">
            <li><a href="#">Layouts</a>
            	<ul>
            		<li><a href="sub1.php">Left Sidebar</a></li>
            		<li><a href="sub2.php">Right Sidebar</a></li>
            		<li><a href="sub3.php">Half Content/Half Sidebar</a></li>
            	</ul>
            </li>
            <li><a href="grid.php">Grid Examples</a></li>
            <li><a href="team.php">Team</a></li>
            <li><a href="locations.php">Locations</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
        
		<a class="menu-trigger ss-icon" href="#menu">Click Here</a>
		<nav id="mobile_menu">
	        <ul>
	            <li><a href="#">Layouts</a>
	            	<ul>
	            		<li><a href="sub1.php">Left Sidebar</a></li>
	            		<li><a href="sub2.php">Right Sidebar</a></li>
	            		<li><a href="sub3.php">Half Content/Half Sidebar</a></li>
	            	</ul>
	            </li>
	            <li><a href="grid.php">Grid Examples</a></li>
       		    <li><a href="team.php">Team</a></li>
	            <li><a href="locations.php">Locations</a></li>
	            <li><a href="contact.php">Contact</a></li>
	        </ul>
        </nav>
					
    </div>

</nav>
