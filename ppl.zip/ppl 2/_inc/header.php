<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width" />
<meta descripton="<?php echo $metaDescription; ?>">
<meta keywords="PPL, Jackson, Tennessee, TN, Milan, Memphis, Dyersburg, Lexington, Lovelville, Trenton, Jobs,
job search, staffing agency, jobs, apply for job, Ben Ferguson, Amy Scarbrough, Tim Melugin, Job Posting, 
Apply for job, Personnel Placements, jobs, LLC, bpi packaging, pervision coils, Colonial, FRS, NSK, HCL Supply,
Employee Services, Employer Services" >

<title><?php echo $title; ?> | PPL Staffing</title>
	<!--
		                      _                                      
		 _| _ _. _  _  __ |_.(_. _   _ _  _ . _  _ _ _. _  _   |_    
		(_|(-_)|(_)| )    |_|| |(_  (-| )(_)|| )(-(-| || )(_)  |_)\/ 
		        _/                       _/               _/      /  
		 ____            _ _                 _   _       _                        
		/ ___|  ___   __| (_)_   _ _ __ ___ | | | | __ _| | ___   __ _  ___ _ __  
		\___ \ / _ \ / _` | | | | | '_ ` _ \| |_| |/ _` | |/ _ \ / _` |/ _ \ '_ \ 
		 ___) | (_) | (_| | | |_| | | | | | |  _  | (_| | | (_) | (_| |  __/ | | |
		|____/ \___/ \__,_|_|\__,_|_| |_| |_|_| |_|\__,_|_|\___/ \__, |\___|_| |_|.com
		                                                         |___/           
	-->
<link rel="stylesheet" href="_styles/reset.css" media="screen" />
<link rel="stylesheet" href="_styles/style.css" media="screen" />
<link rel="stylesheet" href="_styles/mobile_nav.css" media="screen" />
<link rel="icon" 
   		type="img/png"
      href="../_img/favicon.png">

<!-- give life to HTML5 objects in IE -->
<!--[if lte IE 8]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

<!-- js HTML class -->
<script>(function(H){H.className=H.className.replace(/\bno-js\b/,"js")})(document.documentElement)</script>

<script type="text/javascript" src="//use.typekit.net/qqc1ozm.js"></script>
<script type="text/javascript">try{Typekit.load();}catch(e){}</script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>

<?php include ('_inc/google-analytics.php'); ?>


