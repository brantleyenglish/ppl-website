	<?php include ('nav.php'); ?>

    <header class="header home">
        <div class="row">
        	<div class="columns">
	            <div class="headlines">
	                <h1>We connect the right people<br />with the right jobs,<br /><span>right away.</span></h1>
	                <a href="http://worldlink.pplstaffing.com/WL52PROD/main.aspx?action=Get&view=Home" class="button big">Apply for a job today</a>
	                <p>Got a job opening? <a href="employer.php">Post A Job</a></p>
	            </div>
	    	</div>
        </div>
    </header>