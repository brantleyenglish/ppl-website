	<?php include ('nav.php'); ?>

    <header class="header employer">
        <div class="row">
        	<div class="columns">
	            <div class="headlines">
	                <h1>Need to find the perfect employee, meet your deadlines & reduce HR costs?<br /><span>We’ve been doing that for over 20 years.</span></h1>
	                <a href="post-job.php" class="button big">Post your job today</a>
	                <!-- send emails to amy@pplstaffing.com -->
	                <p>Looking for a job? <a href="http://worldlink.pplstaffing.com/WL52PROD/main.aspx?action=Get&view=Home">Apply today</a></p>
	            </div>
	    	</div>
        </div>
    </header>